import axios from 'axios';
import { Transaction } from './types';

// List of known exchange addresses (simplified example)
const KNOWN_EXCHANGES = [
  '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D', // Uniswap Router
  '0x68b3465833fb72A70ecDF485E0e4C7bD8665Fc45', // Uniswap Router V2
  '0x881D40237659C251811CEC9c364ef91dC08D300C', // Metamask Swap Router
  '0x1111111254fb6c44bAC0beD2854e76F90643097d', // 1inch Router
  '0xdef1c0ded9bec7f1a1670819833240f027b25eff', // 0x Exchange
  '5Q544fKrFoe6tsEbD7S8EmxGTJYAKtTVhAW5Q5pge4j1', // Solana example
];

/**
 * Check if an address is a known exchange
 */
export const isExchange = (address: string): boolean => {
  return KNOWN_EXCHANGES.includes(address);
};

/**
 * Fetch Ethereum transactions for a given address
 * 
 * Note: In a real application, this would connect to the Etherscan API
 * or similar service to get actual transaction data.
 */
export const getEthereumTransactions = async (address: string): Promise<Transaction[]> => {
  try {
    // In a real application, we would use this to fetch real data:
    // const apiKey = process.env.ETHERSCAN_API_KEY;
    // const response = await axios.get(
    //   `https://api.etherscan.io/api?module=account&action=txlist&address=${address}&startblock=0&endblock=99999999&sort=desc&apikey=${apiKey}`
    // );
    
    // For demo purposes, generate some sample transactions
    console.log(`Fetching Ethereum transactions for address: ${address}`);
    
    // Example data (note: this will be replaced with real API calls in production)
    const now = Math.floor(Date.now() / 1000);
    const transactions: Transaction[] = [];
    
    // Add real transaction if the address is a known exchange
    if (isExchange(address)) {
      // Sample transactions for exchanges (more numerous)
      for (let i = 0; i < 20; i++) {
        const isOutgoing = Math.random() > 0.5;
        
        transactions.push({
          hash: `0x${Math.random().toString(16).substring(2, 42)}`,
          from: isOutgoing ? address : `0x${Math.random().toString(16).substring(2, 42)}`,
          to: isOutgoing ? `0x${Math.random().toString(16).substring(2, 42)}` : address,
          value: `${(Math.random() * 5).toFixed(4)} ETH`,
          timestamp: now - (i * 86400), // One day apart
        });
      }
    } else {
      // Sample transactions for regular wallets
      for (let i = 0; i < 8; i++) {
        const isOutgoing = Math.random() > 0.5;
        
        transactions.push({
          hash: `0x${Math.random().toString(16).substring(2, 42)}`,
          from: isOutgoing ? address : `0x${Math.random().toString(16).substring(2, 42)}`,
          to: isOutgoing ? `0x${Math.random().toString(16).substring(2, 42)}` : address,
          value: `${(Math.random() * 1.2).toFixed(4)} ETH`,
          timestamp: now - (i * 604800), // One week apart
        });
      }
      
      // Add a transaction to/from an exchange
      const exchangeIdx = Math.floor(Math.random() * 3);
      const exchangeAddress = KNOWN_EXCHANGES[exchangeIdx];
      const isOutgoing = Math.random() > 0.5;
      
      transactions.push({
        hash: `0x${Math.random().toString(16).substring(2, 42)}`,
        from: isOutgoing ? address : exchangeAddress,
        to: isOutgoing ? exchangeAddress : address,
        value: `${(Math.random() * 2).toFixed(4)} ETH`,
        timestamp: now - (9 * 604800),
      });
    }
    
    return transactions;
  } catch (error) {
    console.error('Error fetching Ethereum transactions:', error);
    throw new Error('Failed to fetch Ethereum transactions. Please try again.');
  }
};

/**
 * Fetch Solana transactions for a given address
 * 
 * Note: In a real application, this would connect to the Solana RPC API
 * or similar service to get actual transaction data.
 */
export const getSolanaTransactions = async (address: string): Promise<Transaction[]> => {
  try {
    // In a real application, we would use this to fetch real data:
    // const response = await axios.get(
    //   `https://public-api.solscan.io/account/transactions?account=${address}&limit=10`
    // );
    
    // For demo purposes, generate some sample transactions
    console.log(`Fetching Solana transactions for address: ${address}`);
    
    // Example data (note: this will be replaced with real API calls in production)
    const now = Math.floor(Date.now() / 1000);
    const transactions: Transaction[] = [];
    
    for (let i = 0; i < 8; i++) {
      const isOutgoing = Math.random() > 0.5;
      
      transactions.push({
        hash: Math.random().toString(36).substring(2, 15),
        from: isOutgoing ? address : Math.random().toString(36).substring(2, 15),
        to: isOutgoing ? Math.random().toString(36).substring(2, 15) : address,
        value: `${(Math.random() * 10).toFixed(4)} SOL`,
        timestamp: now - (i * 86400), // One day apart
      });
    }
    
    return transactions;
  } catch (error) {
    console.error('Error fetching Solana transactions:', error);
    throw new Error('Failed to fetch Solana transactions. Please try again.');
  }
};